// Part 1
// Generating an SVG

console.log('hello');
console.log('sup');

const svg = d3.select('svg');

svg.style('background-color', 'red');