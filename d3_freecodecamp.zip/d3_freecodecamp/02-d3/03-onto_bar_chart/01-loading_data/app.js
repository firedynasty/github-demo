// Load data from hours-of-tv-watched.csv

const svg = d3.select('svg');

const width = +svg.attr('width');
const height = +svg.attr('height');


const render = data => {
  svg.selectAll('rect').data(data)
    .enter()
    .append('rect')
    .attr('width', 300)
    .attr('height', 300)
};

//D3 Data Join
// venn diagram
// more entries in the data array than in the DOM 



d3.csv("worldPopulation.csv").then(function(worldData) {
  console.log(worldData);

  worldData.forEach(d=> {
    d.population = +d.population * 1000;
  });
    console.log(worldData);
  // because the data is missing the million at the end

  var population = worldData.map(data=>data.population);
  console.log("population", population);

  // make one rectange for each element in the array
  // see const render
  render(worldData)

}).catch(function(error) {
  console.log(error);
});

