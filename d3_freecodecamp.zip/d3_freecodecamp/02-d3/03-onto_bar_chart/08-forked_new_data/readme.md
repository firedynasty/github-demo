This data is from class. 
