// Load data from hours-of-tv-watched.csv

const svg = d3.select('svg');

const width = +svg.attr('width');
const height = +svg.attr('height');


const render = data => {
  const xValue = d => d.population;
  const yValue = d => d.country;
  // he likes to define variables here to confuse you
  // why does he do that? why is it like that?  who knows
  const margin = { top: 20, right:20, bottom:20, left:20};
  // number of pixels away from the edge
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;


  const xScale = d3.scaleLinear()
    .domain([0, d3.max(data, xValue)])
    // they contain two elements for the argument
    // accepts one row as data input
    .range([0, innerWidth]);
    
  // console.log(xScale.domain());
    // where will xScale be used?

  // check console.log(xScale.range());
    // console.log(xScale.range());
    // correct will yield 0, 960

  const yScale = d3.scaleBand()
    .domain(data.map(yValue))
    .range([0, innerHeight]);
  // guesing this should return an array
  // console.log(yScale.domain())




  const g = svg.append('g')
    .attr('transform', `translate(${margin.left}, ${margin.top})`)

  g.selectAll('rect').data(data)
    .enter()
    .append('rect')
      .attr('y', d => yScale(yValue(d)))
      // yValue(d) same as d.country
      .attr('width', d => xScale(xValue(d)))
      // xValue(d) and xValue are effectively the same thing
      // same as d.population

      .attr('height', yScale.bandwidth());
      // bandwidth is the computed width of a bar
    // will change from 300 to the values that you will see

};

//D3 Data Join
// venn diagram
// more entries in the data array than in the DOM 



d3.csv("worldPopulation.csv").then(function(worldData) {
  console.log(worldData);

  worldData.forEach(d=> {
    d.population = +d.population * 1000;
  });
    console.log(worldData);
  // because the data is missing the million at the end

  var population = worldData.map(data=>data.population);
  console.log("population", population);

  // make one rectange for each element in the array
  // see const render
  render(worldData)

}).catch(function(error) {
  console.log(error);
});

