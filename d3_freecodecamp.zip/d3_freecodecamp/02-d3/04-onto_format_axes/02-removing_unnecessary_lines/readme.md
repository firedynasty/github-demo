The source is from the [United Nations: 2017](https://population.un.org/wpp/Download/Standard/Population). 

The bar chart shows the population of the top 10 most populous countries.  


