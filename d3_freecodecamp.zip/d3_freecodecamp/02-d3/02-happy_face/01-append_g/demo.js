// Part 1
// Generating an SVG



console.log('hello');
console.log('sup');

const svg = d3.select('svg');

// make a circle
// so use attr to extract svg

const width = parseFloat(svg.attr('width'));
// a common shorthand of parseFloat is + 

console.log(typeof width, width);

const height = +svg.attr('height');

console.log(typeof height, height)
// because this is already defined 
// why is it being returned as a string? 
// because all html is defined as strings in the DOM


// circle.attr('r', height/2);

// // will only see the quarter of it

// circle.attr('cx', width/2);
// // svg is at 960

// circle.attr('cy', 500/2);


// so can chain circle.attr
// method chaining

const g = svg.append('g')
  .attr('transform', "translate(500, 250)");


const circle = g.append('circle')
// cons height = 500;
// const width = 960;
    .attr('r', height/2)
    // .attr('cx', width / 2)
    // .attr('cy', height / 2) 
    // can delete because that's where the group element is
    .attr('fill', 'yellow')
    .attr('stroke', 'black')

// for right eye and left eye when you see duplicate logic:
// of 100

// const leftEye = g.append('circle')
//     .attr('r', 30)
//     .attr('cx', width/ 2 - 100)
//     .attr('cy', height/ 2 - 70)
//     .attr('fill', 'black');

// const rightEye = svg.append('circle')
//     .attr('r', 30)
//     .attr('cx', width/ 2 + 100)
//     .attr('cy', height/ 2 - 70)
//     .attr('fill', 'black');

// const eyeSpacing = 100;
// const eyeYOffset = 70;

// // const leftEye = svg.append('circle')
// //     .attr('r', 30)
// //     .attr('cx', width/ 2 - eyeSpacing)
// //     .attr('cy', height/ 2 - eyeYOffset)
// //     .attr('fill', 'black');

// // const rightEye = svg.append('circle')
// //     .attr('r', 30)
// //     .attr('cx', width/ 2 + eyeSpacing)
// //     .attr('cy', height/ 2 - eyeYOffset)
// //     .attr('fill', 'black');

// const leftEye = g.append('circle')
//     .attr('r', 30)
//     .attr('cx', -eyeSpacing)
//     .attr('cy', eyeYOffset)
//     .attr('fill', 'black');

// const rightEye = g.append('circle')
//     .attr('r', 30)
//     .attr('cx', eyeSpacing)
//     .attr('cy', eyeYOffset)
//     .attr('fill', 'black');

// // Documentation : https://github.com/d3/d3-shape/blob/v2.0.0/README.md#arcs
// // this will draw the path



// // var arc = d3.arc()
// //     .innerRadius(150)
// //     .outerRadius(170)
// //     .startAngle(Math.PI * (Math.PI/2)) //convert from degs to radians
// //     .endAngle(Math.PI * 3/2) //just radians

// // const mouth = svg.append("path")
// //     .attr("d", arc)


// // const mouth = svg.append('path')
// //     .attr('d', arc()({
// //         innerRadius: 150,
// //         outerRadius: 170, 
// //         startAngle: Math.PI /2, 
// //         endAngle: Math.PI*3/2,

// //     }));
